package com.exitAssignment.server.model;

/**
 * The jwtRequest class represents a request object for JWT (JSON Web Token) authentication.
 * Written by Yashaswi Srivastava.
 */
public class jwtRequest {
    private String username; // Username for authentication
    private String password; // Password for authentication

    // Default constructor
    public jwtRequest() {}

    // Parameterized constructor
    public jwtRequest(String username, String password) {
        super();
        this.username = username;
        this.password = password;
    }

    // Getter and setter methods for username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Getter and setter methods for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
