package com.exitAssignment.server.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exitAssignment.server.dao.NoteDao;
import com.exitAssignment.server.dao.UserDao;
import com.exitAssignment.server.model.Note;
import com.exitAssignment.server.model.User;

/***
 * @author Yashaswi Srivastava
 */

@Service
public class NoteService {
	
	@Autowired
	private NoteDao NoteDao;
	
	@Autowired
	private UserDao userDao;

	public List<Note> getNote() {
		// This method retrieves all the Notes from the database.
		return this.NoteDao.findAll();
	}
	
	public void deleteNote(int id) {
	    // This method deletes a Note from the database based on its ID.
	    // It takes the ID as a parameter and uses the deleteById() method of the NoteDao.
	    NoteDao.deleteById(id);
	}
	
	public Note addNote(Note Note) {
		// This method adds a new Note to the database.
		//To add the notes to the system
		// Otherwise, it saves the Note using the save() method of the NoteDao and returns the saved Note.

		Note NoteId = this.NoteDao.findByNoteId(Note.getNoteId());
		System.out.println(NoteId);
		if (NoteId != null) {
			return null;
		}
		return this.NoteDao.save(Note);
	}
	
	public List<Note> getNoteByName(String NoteName) {
		// This method retrieves Notes from the database based on their name.
		// It takes the NoteName as a parameter.
		// It uses the findByNoteName() method of the NoteDao to get the Notes matching the given name.
		// The Notes are returned as a List<Note>.

		List<Note> Note = this.NoteDao.findByNoteName(NoteName);
		return Note;
	}

	public Note getNoteById(int id) {
		// This method retrieves a Note from the database based on its ID.
		// It takes the ID as a parameter.

		Note Note = null;
		try {
			Note = NoteDao.findByNoteId(id);
		} catch (NoSuchElementException e) {
			System.out.println("No Note with this id");
		}
		//System.out.println(Note);

		return Note;
	}
	
	public Long getNumberofNotes() {
		// This method returns the total number of Notes in the database.
		// It uses the count() method of the NoteDao to get the count.
		return this.NoteDao.count();
	}
	
	public void simpleScheduledTask() {
	    // This method is a scheduled task that runs periodically.

	    // Fetch a list of all users from the database
	    List<User> users = userDao.findAll();

	    // Iterate through each user in the list
	    for (User user : users) {

	        try {
	            // Attempt to fetch a list of notes for the current user, ordered by time
	            List<Note> userNotes = NoteDao.findNotesByUserIdOrderByTime(user.getId());

	            // Check if there are more than 10 notes for the user
	            if (userNotes.size() > 10) {
	                // If there are more than 10 notes, create a sublist of the oldest notes
	                List<Note> notesToDelete = userNotes.subList(0, userNotes.size() - 10);

	                // Delete the oldest notes from the database
	                NoteDao.deleteAll(notesToDelete);
	            }
	        } catch (Exception e) {
	            // If an exception occurs during note retrieval or deletion, log the error
	            System.out.println(e);
	        }
	    }
	}

	
//	@Scheduled(fixedRate = 10) // Run every hour
//    public void cleanupOldestNotes() {
//        System.out.println("Hellooooo schedule ho rha");
//
//        List<User> users = userDao.findAll();
//        for (User user : users) {
//            List<Note> userNotes = NoteDao.findTop10ByUserOrderByTimeAsc(user.getId());
//            if (userNotes.size() > 10) {
//                List<Note> notesToDelete = userNotes.subList(0, userNotes.size() - 10);
//                NoteDao.deleteAll(notesToDelete);
//            }
//        }
//    }
}
