package com.exitAssignment.server;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.exitAssignment.server.service.NoteService;


// This component represents a cleanup task that implements the Runnable interface
@Component
public class cleanupTask implements Runnable {
    private final NoteService noteService;

    // Constructor for injecting NoteService
    @Autowired
    public cleanupTask(NoteService noteService) {
        this.noteService = noteService;
    }

    // This method is executed when the task is triggered
    @Override
    public void run() {
        // Delegates the cleanup task to the NoteService
        noteService.simpleScheduledTask();
    }
}
