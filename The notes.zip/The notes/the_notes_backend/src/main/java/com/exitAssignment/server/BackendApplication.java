package com.exitAssignment.server;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The main class that starts the backend application.
 */
@SpringBootApplication
public class BackendApplication {

    @Autowired
    private ScheduledExecutorService scheduledExecutorService;

    @Autowired
    private cleanupTask cleanupTask;

    public static void main(String[] args) {
        // The SpringApplication.run() method starts the Spring Boot application.
        // It takes the class of the application (BackendApplication) and the command-line arguments as parameters.
        SpringApplication.run(BackendApplication.class, args);

        // Print a simple greeting message to the console
        System.out.println("Hey there!");
    }

    // This method is executed after the application context has been initialized
    @PostConstruct
    public void scheduleCleanupTask() {
        // Schedule the cleanup task to run periodically
        scheduledExecutorService.scheduleAtFixedRate(
            cleanupTask,
            0, // Initial delay (start immediately)
            1, // Repeat every 1 hour
            TimeUnit.HOURS
        );
    }

    /*
    public void run(String... args) throws Exception {
        // Code for user and role setup (commented out)
    }
    */
}
