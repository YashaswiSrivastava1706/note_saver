package com.exitAssignment.server.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.exitAssignment.server.dao.UserDao;
import com.exitAssignment.server.model.User;

@Service
public class UserService {

	@Autowired
	private UserDao userDao;

	// Scheduled task that runs every 5 seconds
	@Scheduled(fixedRate = 5000)
	public void simpleScheduledTask() {
		System.out.println("Scheduled task is running user ki!");
	}

	/**
	 * Retrieves all users from the database.
	 * 
	 * @return List of all users
	 */
	public List<User> getAllUser() {
		// This method retrieves all the users from the database.
		// It uses the findAll() method of the UserDao to get all the users.
		// The users are returned as a List<User>.
		return this.userDao.findAll();
	}

	/**
	 * Retrieves a user by their username.
	 * 
	 * @param userName the username of the user to retrieve
	 * @return the user if found, otherwise null
	 */
	public User getUserByUserName(String userName) {
		// This method retrieves a user from the database based on their username.
		// It takes the userName as a parameter.
		// It uses the findByUsername() method of the UserDao to get the user with the given username.
		// If a user is found, it returns the user. Otherwise, it returns null.

		User user = this.userDao.findByUsername(userName);
		if (user != null) {
			return user;
		} else {
			return null;
		}
	}

	/**
	 * Add a user along with their associated roles.
	 * 
	 * @param user      the user to be added
	 * @return the added user if successful, otherwise null
	 */
	public User addUser(User user) {
		// This method adds a new user to the database.
		// It takes the user object as a parameter.
		// First, it checks if a user with the same username already exists using the findByUsername() method of the UserDao.
		// If a user with the same username exists, it returns null to indicate that the user cannot be added.
		// Otherwise, it saves the user using the save() method of the UserDao and returns the saved user.

		User userName = this.userDao.findByUsername(user.getUserName());
		if (userName != null) {
			return null;
		}
		
		this.userDao.save(user);
		
		return user;
	}

	/**
	 * Retrieves a user by their username and password.
	 * 
	 * @param userName the username of the user to retrieve
	 * @param password the password of the user to retrieve
	 * @return the user if found, otherwise null
	 */
	public User getUserByUsernameAndPassword(String userName, String password) {
		// This method retrieves a user from the database based on their username and password.
		// It takes the userName and password as parameters.
		// It uses the findByUsernameAndPassword() method of the UserDao to get the user with the given username and password.
		// If a user is found, it returns the user. Otherwise, it returns null.

		User user = this.userDao.findByUsernameAndPassword(userName, password);
		if (user == null) {
			return null;
		}
		return user;
	}

	/**
	 * Gets the total number of users in the database.
	 * 
	 * @return the total number of users
	 */
	public Long getCountUser() {
		// This method returns the total number of users in the database.
		// It uses the count() method of the UserDao to get the count.
		// The count is returned as a Long value.
		
		return this.userDao.count();
	}
}
