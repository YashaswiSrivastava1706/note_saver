package com.exitAssignment.server.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

/**
 * The SchedulerConfig class provides configuration for scheduling tasks.
 * Author: Yashaswi Srivastava
 */
@Configuration
public class SchedulerConfig {

    /**
     * Creates a single-threaded ScheduledExecutorService bean.
     *
     * @return A ScheduledExecutorService bean for scheduling tasks.
     */
    @Bean
    public ScheduledExecutorService scheduledExecutorService() {
        return Executors.newSingleThreadScheduledExecutor();
    }
}
