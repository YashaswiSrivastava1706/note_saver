package com.exitAssignment.server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exitAssignment.server.model.User;
import com.exitAssignment.server.service.UserService;

import at.favre.lib.crypto.bcrypt.BCrypt;

/**
 * This UserController class handles user-related HTTP requests and serves as the REST API endpoint for user operations.
 * It is responsible for user registration, retrieval of user data, and user count.
 * Author: Yashaswi Srivastava
 */
@CrossOrigin
@RequestMapping("/api")
@RestController
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/")
	public String find() {
		// Sample endpoint for testing the user API
		return "This is user API";
	}
	
	@SuppressWarnings("rawtypes")
	@PostMapping("/register")
	public ResponseEntity register(@RequestBody User user) {
		// Register a new user
		
		// Hash the user's password using BCrypt
		String bcryptHashString = BCrypt.withDefaults().hashToString(12, user.getPassword().toCharArray());
		user.setPassword(bcryptHashString);
		
		User createUser = userService.addUser(user);
		
		if (createUser == null) {
			// User registration failed
			return ResponseEntity.status(401).build();
		} else {
			// User registration successful
			return ResponseEntity.status(200).build();
		}
	}
	
	@GetMapping("/{username}")
	public User getUserByName(@PathVariable String username) {
		// Retrieve a user by their username
		return this.userService.getUserByUserName(username);
	}
	
	@GetMapping("/user")
	public List<User> getAllUsers() {
		// Retrieve all users
		return this.userService.getAllUser();
	}
	
	@GetMapping("/count-users")
	public Long getUserCount() {
		// Get the count of users
		return this.userService.getCountUser();
	}
}

