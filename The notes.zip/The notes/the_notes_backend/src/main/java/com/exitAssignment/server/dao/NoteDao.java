package com.exitAssignment.server.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.exitAssignment.server.model.Note;

@Repository
public interface NoteDao extends JpaRepository<Note, Integer> {
	
	
	// findByProductName(): This method is used to search for products by their name.
	// It takes a String parameter representing the product name and returns a List of products with matching names.
	public List<Note> findByNoteName(String noteName);
	
	@Query(value = "SELECT * FROM note WHERE user = :userId ORDER BY time ASC", nativeQuery = true)
    List<Note> findNotesByUserIdOrderByTime(int userId);	// findByProductId(): This method is used to search for a product by its ID.
	
	// It takes an int parameter representing the product ID and returns the product with the matching ID.
	public Note findByNoteId(int noteId);
}
