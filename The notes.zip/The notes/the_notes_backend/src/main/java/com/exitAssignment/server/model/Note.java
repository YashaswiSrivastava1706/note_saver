package com.exitAssignment.server.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@Entity
@Table(name = "note")
/**
 * The Note class represents a note entity in the application.
 * Written by Yashaswi Srivastava.
 */
public class Note {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int noteId; // Unique identifier for the note
    private String noteName; // Name of the note
    private String contentName; // Content of the note
    private String time; // Timestamp for when the note was created
    private int user; // User associated with the note

    // Constructors
    public Note(int noteId, String noteName, String contentName, String time, int user) {
        super();
        this.noteId = noteId;
        this.noteName = noteName;
        this.contentName = contentName;
        this.time = time;
        this.user = user;
    }

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }

    // Default constructor
    public Note() {}

    // Getter and setter methods for entity attributes
    public int getNoteId() {
        return noteId;
    }

    public void setNoteId(int noteId) {
        this.noteId = noteId;
    }

    public String getNoteName() {
        return noteName;
    }

    public void setNoteName(String noteName) {
        this.noteName = noteName;
    }

    public String getContentName() {
        return contentName;
    }

    public void setContentName(String contentName) {
        this.contentName = contentName;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    // toString method for debugging and logging
    @Override
    public String toString() {
        return "Note [noteId=" + noteId + ", noteName=" + noteName + ", contentName=" + contentName + ", time=" + time
                + ", user=" + user + "]";
    }
}
