package com.exitAssignment.server.model;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
public class User implements UserDetails {
    private static final long serialVersionUID = 1L;

    // Default constructor
    public User() {}

    // Entity attributes
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String firstName;
    private String lastName;
    private String username;
    private String password;

    // Constructors
    public User(int id, String firstName, String lastName, String username, String password) {
        super();
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
    }

    // Getter and setter methods for entity attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return username;
    }

    public void setUserName(String userName) {
        this.username = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // toString method for debugging and logging
    @Override
    public String toString() {
        return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", username=" + username
                + ", password=" + password + "]";
    }

    // Methods required by the UserDetails interface (used for authentication and authorization)
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // In a real application, you would return a set of user roles/authorities here
        // For simplicity, an empty set is returned in this example
        Set<Authority> set = new HashSet<>();
        return set;
    }

    @Override
    public String getUsername() {
        // Return the username as required by UserDetails interface
        return getUserName();
    }

    @Override
    public boolean isAccountNonExpired() {
        // Return true if the user's account is not expired
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        // Return true if the user's account is not locked
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        // Return true if the user's credentials are not expired
        return true;
    }

    @Override
    public boolean isEnabled() {
        // Return true if the user's account is enabled
        return true;
    }
}
