package com.exitAssignment.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.exitAssignment.server.model.User;

@Repository
public interface UserDao extends JpaRepository<User, Integer> {
	
	// This interface extends JpaRepository, which provides the basic CRUD operations for the User entity.

	// Custom methods for querying user data can be defined in this interface.
	
	public User findByUsernameAndPassword(String username, String password);
	// This method is used to find a user by their username and password.
	// It accepts two parameters: username and password.

	public User findByUsername(String userName);
	// This method is used to find a user by their username.
	// It accepts a single parameter: the username.
	// In addition, custom methods can be defined to perform specific queries on User data using Spring Data JPA's query generation mechanism.
}
