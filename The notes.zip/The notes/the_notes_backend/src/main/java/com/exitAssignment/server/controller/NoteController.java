package com.exitAssignment.server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exitAssignment.server.model.Note;
import com.exitAssignment.server.service.NoteService;

/**
 * The NoteController class handles HTTP requests related to Notes, serving as the REST API endpoint for Note operations.
 * Author: Yashaswi Srivastava
 */
@CrossOrigin("*")
@RequestMapping("/api")
@RestController
public class NoteController {
	
	@Autowired
	private NoteService noteService;
	
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/all-notes")
	public List<Note> getAllNotes() {
		// Retrieve all Notes from the NoteService
		return this.noteService.getNote();
	}
	
	@Scheduled // Scheduled task, runs every hour
	public void simpleScheduledTask() {
	    System.out.println("Scheduled task is running in the controller!");
	}
	
	@CrossOrigin()
	@PostMapping("/add-notes")
	public Note addNote(@RequestBody Note note) {
		// Add a new Note using the NoteService
		return this.noteService.addNote(note);
	}
	
	@SuppressWarnings("rawtypes")
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/search/{noteName}")
	public ResponseEntity getNotesByName(@PathVariable String noteName) {
		// Search for Notes by name using the NoteService
		List<Note> notes = this.noteService.getNoteByName(noteName);

		if (notes == null) {
			// If no Note is found, return a 401 Unauthorized response
			return ResponseEntity.status(401).build();
		}
		
		// If Notes are found, return a 200 OK response with the Note list
		return ResponseEntity.status(200).body(notes);
	}
	
	@GetMapping("/note/{id}")
	public Note getNoteById(@PathVariable int id) {
		// Retrieve a Note by its ID using the NoteService
		return this.noteService.getNoteById(id);
	}
	
	@GetMapping("/count-notes")
	public Long getNoteCount() {
		// Get the count of Notes using the NoteService
		return this.noteService.getNumberofNotes();
	}
	
	@SuppressWarnings("rawtypes")
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/delete/{id}")
	public ResponseEntity deleteNote(@PathVariable int id) {
	    // Delete a Note by its ID using the NoteService
	    try {
	        noteService.deleteNote(id);
	        return ResponseEntity.status(200).build(); // 200 OK if successful
	    } catch (EmptyResultDataAccessException e) {
	        // If no Note with the given ID is found, return a 404 Not Found response
	        return ResponseEntity.status(404).build();
	    }
	}
}
