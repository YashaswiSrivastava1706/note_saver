import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddNotesComponent } from './components/add-notes/add-notes.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { SearchComponent } from './components/search/search.component';
import { ViewDetailsComponent } from './components/view-details/view-details.component';
import { AuthGuard } from './components/services/auth.guard';
import { ViewReviewComponent } from './components/view-review/view-review.component';

const routes: Routes = [
  {
    path: 'login', // Route path for the login page
    component: LoginComponent, // Component to be rendered for the login page
    pathMatch: 'full' // Matches the full path
  },
  {
    path: 'register', // Route path for the register page
    component: RegisterComponent, // Component to be rendered for the register page
    pathMatch: 'full' // Matches the full path
  },
  {
    path: 'search', // Route path for the search page
    component: SearchComponent, // Component to be rendered for the search page
    pathMatch: 'full', // Matches the full path
    canActivate: [AuthGuard] // Guard to check if user is authenticated
  },
  {
    path: 'view-notes', // Route path for the view notes page
    component: ViewDetailsComponent, // Component to be rendered for the view notes page
    pathMatch: 'full', // Matches the full path
    canActivate: [AuthGuard] // Guard to check if user is authenticated
  },
  {
    path: 'add-notes', // Route path for the add notes page
    component: AddNotesComponent, // Component to be rendered for the add notes page
    pathMatch: 'full', // Matches the full path
    canActivate: [AuthGuard] // Guard to check if user is authenticated
  },
  {
    path: 'view-review/:noteId', // Route path for the view review page with noteId parameter
    component: ViewReviewComponent, // Component to be rendered for the view review page
    pathMatch: 'full', // Matches the full path
    canActivate: [AuthGuard] // Guard to check if user is authenticated
  },
  {
    path: 'view-review', // Route path for the view review page
    component: ViewReviewComponent, // Component to be rendered for the view review page
    pathMatch: 'full', // Matches the full path
    canActivate: [AuthGuard] // Guard to check if user is authenticated
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
