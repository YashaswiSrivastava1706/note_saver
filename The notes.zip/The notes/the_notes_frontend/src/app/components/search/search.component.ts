import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';

@Component({
  selector: 'search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private userService: UserService) { }

  noteName: any; // Variable to store the note name entered by the user
  message: any; // Variable to store the search result message
  note: any; // Variable to store the retrieved note data

  ngOnInit(): void {
  }

  searchBynoteName() {
    // Call the getnoteByNoteName() method from the userService to search for notes by note name
    this.userService.getnoteByNoteName(this.noteName).subscribe(
      res => {
        console.log(res);
        this.note = res; // Assign the retrieved data to the note variable
        console.log("In this", this.note);
        if (this.note.length == 0) {
          this.message = "No note found"; // Display a message if no notes are found
        } else {
          this.message = ''; // Clear the message if notes are found
        }
      },
      error => {
        console.log(error); // Log any errors that occur during the search process
      }
    );
  }

}
