import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'view-review',
  templateUrl: './view-review.component.html',
  styleUrls: ['./view-review.component.css']
})
export class ViewReviewComponent implements OnInit {

  constructor(
    private userService: UserService,
    private router: ActivatedRoute
  ) { }

  list: any; // Variable to store the retrieved note data

  ngOnInit(): void {
    // Retrieve the note data by calling the getnoteById() method from the user service
    // and subscribing to the returned observable
    this.userService.getNoteById(this.router.snapshot.params['noteId']).subscribe(data => {
      this.list = data; // Assign the retrieved data to the list variable
    });
  }
}
