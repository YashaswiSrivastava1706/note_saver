import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';

@Component({
  selector: 'view-notes',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent implements OnInit {

  constructor(private userService: UserService) { }

  collection: any; // Variable to store the retrieved note data
  currentUser: any; // Variable to store the current user
 
  ngOnInit(): void {
    // Call the allNotes() method from the userService to get all notes and subscribe to the returned observable
    this.currentUser = localStorage.getItem('CurrentUser');

    this.userService.allNotes().subscribe((result) => {
      console.log("hiiiiiiiiiiiiiiiiiii"+result)
      this.collection = result; // Assign the retrieved data to the collection variable
      this.collection = this.collection.filter((item: any) => item.user == this.currentUser)
  .sort((a: any, b: any) => b.time - a.time);
  console.log("hiiiiiiiiiiiiiiiiiii"+this.collection)
  this.collection = this.collection.slice(-10); 
 // Sort by createdAt and take the first 10
    }, err => {
      console.log(err); // Log any errors that occur during the retrieval process
    });

  }
  getCurrentUser(): any {
    return localStorage.getItem('CurrentUser') || ''; // Replace with the correct key for user ID in localStorage
  }

    // Function to delete a notes by its ID
    deleteNote(noteId: number): void {
      if (confirm('Are you sure you want to delete this note?')) {
        this.userService.deleteNote(noteId).subscribe(
          () => {
            // Note deleted successfully, update the UI by removing the deleted note from the collection
            this.collection = this.collection.filter((item: any) => item.noteId !== noteId);
            console.log('Note deleted successfully');
          },
          (error) => {
            // Handle error, e.g., display an error message.
            console.error('Error deleting note:', error);
          }
        );
      }
    }
  
}
