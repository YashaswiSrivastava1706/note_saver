import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';

@Component({
  selector: 'add-notes',
  templateUrl: './add-notes.component.html',
  styleUrls: ['./add-notes.component.css']
})
export class AddNotesComponent implements OnInit {
  message='';
  currentTime: any;
  public note = {
    noteName:'',
    contentName:'',
    time:'',
    user:0
  };

  

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    // This method is called when the component is initialized
    this.note.user = this.getUserIdFromLocalStorage(); // Set userId from localStorage
    this.note.time = this.getCurrentTime();

  }

  getUserIdFromLocalStorage(): any {
    return localStorage.getItem('CurrentUser') || 0; // Replace with the correct key for user ID in localStorage
  }

  addnote() {
    // This method is called when the user clicks the "Add Note" button
  const contentIsValid = /^[A-Za-z0-9,;@&*+\-\[\]\s]{1,500}$/.test(this.note.contentName);

  if (!contentIsValid) {
    alert("Content is invalid. Only alphabets, numerics, spaces, and the special characters @ , ; & * + - ] [ are allowed, and the content should not exceed 500 characters.");
    return; // Exit the function without saving the noteontent is invalid. Only alphabets, numerics, and ;,!(}) are allowed.");
    
    }
    else{
    if (this.note.noteName && this.note.contentName) {
      // Check if all required fields are filled
      this.userService.addNotes(this.note)
        .subscribe(
          (data) => {
            console.log(data);
            window.location.reload(); // Reload the page to clear the form
          },
          (error) => {
            console.log(error);
            this.message = "Enter valid values"; // Display an error message if duplicate values are entered
          }
        );
    }
  }
}
// Function to filter unwanted characters
filterInput(event: KeyboardEvent): void {
  const allowedCharacters = /^[a-zA-Z0-9@.; &+\-)(\s]*$/;
  const inputElement = event.target as HTMLInputElement;
  const inputValue = inputElement.value;
  const newValue = inputValue.replace(new RegExp(`[^${allowedCharacters.source}]`, 'g'), '');
  if (inputValue !== newValue) {
    inputElement.value = newValue;
    this.note.contentName = newValue; // Update the ngModel value
  }
}
  getCurrentTime() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
  }
  reloadPage(): void {
    // Helper method to reload the page
    window.location.reload();
  }
}
