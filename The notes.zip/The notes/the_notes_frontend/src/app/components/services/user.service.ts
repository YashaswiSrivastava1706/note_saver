import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders } from '@angular/common/http';
const baseUrl="http://localhost:9090/api";
 
@Injectable({
  providedIn: 'root'
})
export class UserService {
  token:any;
  constructor(private http:HttpClient) { }

  public getCurrentUser()
  {
    return this.http.get(`${baseUrl}/currentuser`)
  }
  //add user
  addUser(user:any)
  {
    return this.http.post(`${baseUrl}/register`,user);
  }

  public deleteNote(noteId: number) {
    console.log("xxxx"+noteId);

    return this.http.get(`${baseUrl}/delete/${noteId}`);
  }

  //generate tokem

  public generateToken(userdata:any)
  {
    console.log(userdata)
    return this.http.post(`${baseUrl}/generate-token`,userdata);
  }

  //login user: set Token in LocalStorage

  loginUser(token:any)
  {
    localStorage.setItem("token",token)
    return true;
  }

  //User if Loggedin or not

  isLoggedIn()
  {
    let token=sessionStorage.getItem('token');
    // console.log("in tokrn",token);
    if(token==undefined || token==null || token =="")
    {
      return false;
    }
    else{
      return true;
    }
  }
  // logout: remove TOken from LocalStroage

  logout()
  {
    sessionStorage.removeItem("token");
    localStorage.removeItem('token');
    localStorage.removeItem('CurrentUser');

    return true;
  }
  //get Token
  public getToken()
  {
   
    return localStorage.getItem('token');
  }
//All note
  public allNotes() {
    return this.http.get(`${baseUrl}/all-notes`)
  }
  // Add note
  public addNotes(note:any) {
console.log(note)
    return this.http.post(`${baseUrl}/add-notes`,note);
  }

  public getnoteByNoteName(noteName:any)
  {
    
    return this.http.get(`${baseUrl}/search/${noteName}`);

  }
  // add reviews


  public getnoteByNoteId(noteId:any)
  {
    let myToken= `Bearer ${sessionStorage.getItem("token")}`
    // console.log("MyToken",myToken,noteName)
   
    return this.http.get(`${baseUrl}/note/${noteId}`);

  }
  // return Loggin User 
  

  public getNoteById(id:any)
  {
    return this.http.get(`${baseUrl}/note/${id}`)

    
  }
 

  public getCountUser()
  {
    return this.http.get(`${baseUrl}/count-users`);
  }
  public getCountNotes()
  {
    return this.http.get(`${baseUrl}/count-notes`);
  }
}
